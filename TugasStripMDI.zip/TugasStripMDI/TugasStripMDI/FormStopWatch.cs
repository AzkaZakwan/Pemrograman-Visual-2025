﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasStripMDI
{
    public partial class menuStopWatch: Form
    {
        private int timeSecn, timeMnt;
        private bool isActive;
        public menuStopWatch()
        {
            InitializeComponent();
        }

        private void MulaiSW_Click(object sender, EventArgs e)
        {            
            isActive = true;
        }

        private void pauseSW_Click(object sender, EventArgs e)
        {
            isActive = false;
        }
        private void berhentiSW_Click_1(object sender, EventArgs e)
        {
            isActive = false;            
            timeSecn = 0;
            timeMnt = 0;
            menampilakan();
        }

        private void timerSW_Tick(object sender, EventArgs e)
        {
            if (isActive)
            {
                timeSecn++;

                if (timeSecn >= 60) 
                {
                    timeSecn = 0;
                    timeMnt++;
                }
            }

            menampilakan();
        }


        private void menampilakan()
        {
            labelSec.Text = String.Format("{0:00}", timeSecn);            
            labelMnt.Text = String.Format("{0:00}", timeMnt);
        }


        private void menuStopWatch_Load(object sender, EventArgs e)
        {           
            timeSecn = 0;
            timeMnt = 0;

            isActive = false;
        }
    }
}
