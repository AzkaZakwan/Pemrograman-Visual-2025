﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasStripMDI
{
    public partial class MainForm : Form
    {
        private menuStopWatch stpwch;
        private FormTimer tmer;
            

        public MainForm()
        {
            InitializeComponent(); 
        }
        private void stpwch_ditutup(Object sender, FormClosedEventArgs e)
        {
            stpwch = null;            
        }

        private void tmer_ditutup(Object sender, FormClosedEventArgs e)
        {
            tmer = null;
        }

        private void stopWatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (stpwch == null)
            {
                stpwch = new menuStopWatch();
                stpwch.MdiParent = this;
                stpwch.FormClosed += new FormClosedEventHandler(stpwch_ditutup);
                stpwch.Show();      
            }
            else
            {
                stpwch.Activate();
            }

        }

        private void timerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tmer == null)
            {
                tmer = new FormTimer();
                tmer.MdiParent = this;
                tmer.FormClosed += new FormClosedEventHandler(tmer_ditutup);
                tmer.Show();
            }
            else
            {
                tmer.Activate();
            }
        }
        
    }
}
