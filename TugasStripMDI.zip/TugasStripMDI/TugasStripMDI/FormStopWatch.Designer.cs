﻿namespace TugasStripMDI
{
    partial class menuStopWatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuStopWatch));
            this.pauseSW = new System.Windows.Forms.Button();
            this.MulaiSW = new System.Windows.Forms.Button();
            this.judulSW = new System.Windows.Forms.Label();
            this.labelMnt = new System.Windows.Forms.Label();
            this.labelBreakPoint = new System.Windows.Forms.Label();
            this.labelSec = new System.Windows.Forms.Label();
            this.timerSW = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.berhentiSW = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pauseSW
            // 
            this.pauseSW.Location = new System.Drawing.Point(283, 287);
            this.pauseSW.Name = "pauseSW";
            this.pauseSW.Size = new System.Drawing.Size(203, 50);
            this.pauseSW.TabIndex = 1;
            this.pauseSW.Text = "Pause";
            this.pauseSW.UseVisualStyleBackColor = true;
            this.pauseSW.Click += new System.EventHandler(this.pauseSW_Click);
            // 
            // MulaiSW
            // 
            this.MulaiSW.Location = new System.Drawing.Point(52, 287);
            this.MulaiSW.Name = "MulaiSW";
            this.MulaiSW.Size = new System.Drawing.Size(203, 50);
            this.MulaiSW.TabIndex = 2;
            this.MulaiSW.Text = "Mulai";
            this.MulaiSW.UseVisualStyleBackColor = true;
            this.MulaiSW.Click += new System.EventHandler(this.MulaiSW_Click);
            // 
            // judulSW
            // 
            this.judulSW.AutoSize = true;
            this.judulSW.Location = new System.Drawing.Point(77, 81);
            this.judulSW.Name = "judulSW";
            this.judulSW.Size = new System.Drawing.Size(146, 25);
            this.judulSW.TabIndex = 3;
            this.judulSW.Text = "STOPWATCH";
            // 
            // labelMnt
            // 
            this.labelMnt.AutoSize = true;
            this.labelMnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMnt.Location = new System.Drawing.Point(281, 167);
            this.labelMnt.Name = "labelMnt";
            this.labelMnt.Size = new System.Drawing.Size(39, 42);
            this.labelMnt.TabIndex = 4;
            this.labelMnt.Text = "0";
            // 
            // labelBreakPoint
            // 
            this.labelBreakPoint.AutoSize = true;
            this.labelBreakPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBreakPoint.Location = new System.Drawing.Point(363, 167);
            this.labelBreakPoint.Name = "labelBreakPoint";
            this.labelBreakPoint.Size = new System.Drawing.Size(28, 42);
            this.labelBreakPoint.TabIndex = 5;
            this.labelBreakPoint.Text = ":";
            // 
            // labelSec
            // 
            this.labelSec.AutoSize = true;
            this.labelSec.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSec.Location = new System.Drawing.Point(437, 167);
            this.labelSec.Name = "labelSec";
            this.labelSec.Size = new System.Drawing.Size(39, 42);
            this.labelSec.TabIndex = 6;
            this.labelSec.Text = "0";
            // 
            // timerSW
            // 
            this.timerSW.Enabled = true;
            this.timerSW.Interval = 1000;
            this.timerSW.Tick += new System.EventHandler(this.timerSW_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(610, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 7;
            // 
            // berhentiSW
            // 
            this.berhentiSW.Location = new System.Drawing.Point(509, 287);
            this.berhentiSW.Name = "berhentiSW";
            this.berhentiSW.Size = new System.Drawing.Size(203, 50);
            this.berhentiSW.TabIndex = 8;
            this.berhentiSW.Text = "Berhenti";
            this.berhentiSW.UseVisualStyleBackColor = true;
            this.berhentiSW.Click += new System.EventHandler(this.berhentiSW_Click_1);
            // 
            // menuStopWatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.berhentiSW);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelSec);
            this.Controls.Add(this.labelBreakPoint);
            this.Controls.Add(this.labelMnt);
            this.Controls.Add(this.judulSW);
            this.Controls.Add(this.MulaiSW);
            this.Controls.Add(this.pauseSW);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "menuStopWatch";
            this.Text = "Stop Watch";
            this.Load += new System.EventHandler(this.menuStopWatch_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button pauseSW;
        private System.Windows.Forms.Button MulaiSW;
        private System.Windows.Forms.Label judulSW;
        private System.Windows.Forms.Label labelMnt;
        private System.Windows.Forms.Label labelBreakPoint;
        private System.Windows.Forms.Label labelSec;
        private System.Windows.Forms.Timer timerSW;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button berhentiSW;
    }
}