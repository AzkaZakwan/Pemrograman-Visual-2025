﻿namespace TugasStripMDI
{
    partial class FormTimer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTimer));
            this.labelMulai = new System.Windows.Forms.Label();
            this.labelBerhenti = new System.Windows.Forms.Label();
            this.btnMulai = new System.Windows.Forms.Button();
            this.btnBerhenti = new System.Windows.Forms.Button();
            this.Scnd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.boxWaktu = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelMulai
            // 
            this.labelMulai.AutoSize = true;
            this.labelMulai.Location = new System.Drawing.Point(225, 282);
            this.labelMulai.Name = "labelMulai";
            this.labelMulai.Size = new System.Drawing.Size(0, 25);
            this.labelMulai.TabIndex = 0;
            // 
            // labelBerhenti
            // 
            this.labelBerhenti.AutoSize = true;
            this.labelBerhenti.Location = new System.Drawing.Point(438, 282);
            this.labelBerhenti.Name = "labelBerhenti";
            this.labelBerhenti.Size = new System.Drawing.Size(0, 25);
            this.labelBerhenti.TabIndex = 1;
            // 
            // btnMulai
            // 
            this.btnMulai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMulai.Location = new System.Drawing.Point(121, 283);
            this.btnMulai.Name = "btnMulai";
            this.btnMulai.Size = new System.Drawing.Size(225, 47);
            this.btnMulai.TabIndex = 2;
            this.btnMulai.Text = "Mulai";
            this.btnMulai.UseVisualStyleBackColor = true;
            this.btnMulai.Click += new System.EventHandler(this.btnMulai_Click);
            // 
            // btnBerhenti
            // 
            this.btnBerhenti.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBerhenti.Location = new System.Drawing.Point(424, 281);
            this.btnBerhenti.Name = "btnBerhenti";
            this.btnBerhenti.Size = new System.Drawing.Size(225, 48);
            this.btnBerhenti.TabIndex = 3;
            this.btnBerhenti.Text = "Berhenti";
            this.btnBerhenti.UseVisualStyleBackColor = true;
            this.btnBerhenti.Click += new System.EventHandler(this.btnBerhenti_Click);
            // 
            // Scnd
            // 
            this.Scnd.AutoSize = true;
            this.Scnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Scnd.Location = new System.Drawing.Point(346, 158);
            this.Scnd.Name = "Scnd";
            this.Scnd.Size = new System.Drawing.Size(68, 73);
            this.Scnd.TabIndex = 7;
            this.Scnd.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 42);
            this.label1.TabIndex = 12;
            this.label1.Text = "Timer";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // boxWaktu
            // 
            this.boxWaktu.Location = new System.Drawing.Point(263, 83);
            this.boxWaktu.Name = "boxWaktu";
            this.boxWaktu.Size = new System.Drawing.Size(100, 31);
            this.boxWaktu.TabIndex = 13;
            // 
            // FormTimer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.boxWaktu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Scnd);
            this.Controls.Add(this.btnBerhenti);
            this.Controls.Add(this.btnMulai);
            this.Controls.Add(this.labelBerhenti);
            this.Controls.Add(this.labelMulai);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTimer";
            this.Text = "FormTimer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMulai;
        private System.Windows.Forms.Label labelBerhenti;
        private System.Windows.Forms.Button btnMulai;
        private System.Windows.Forms.Button btnBerhenti;
        private System.Windows.Forms.Label Scnd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.TextBox boxWaktu;
    }
}