﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasStripMDI
{
    public partial class FormTimer : Form
    {
        private int second = 0;        
        public FormTimer()
        {
            InitializeComponent();
        }

        private void btnMulai_Click(object sender, EventArgs e)
        {            
            if (int.TryParse(boxWaktu.Text, out second) && second > 0)
            {
                Scnd.Text = second.ToString();
                timer.Start();
            }
            else
            {
                MessageBox.Show("Masukkan angka yang valid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
           if (second >= 0)
            {
                Scnd.Text = second--.ToString();                 
            }
            else
            {
                timer.Stop();
            }
        }

        private void btnBerhenti_Click(object sender, EventArgs e)
        {
            timer.Stop();
            second = 0;
            Scnd.Text = "0";
        }
    }
}
